interface Comment {
    _id: string;
    content: string;
    author: string;
    createdAt: Date;
}

export default Comment;
